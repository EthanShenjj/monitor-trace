# td-content-ui-js

无运行时依赖的 Web 模板 UI SDK。调用方提供模板配置，SDK 按模板 ID 展示 UI，通过回调返回交互结果。无需传入 appId、taskId、用户、投递、频控或埋点信息。

## 本地运行

```bash
npm install
npm test
npm run test:browser
npm run dev
```

示例地址：<http://127.0.0.1:4173>。支持五种模板、JSON 编辑和事件查看；动作回调只记录事件，不执行真实跳转或保存今日抑制。浏览器测试默认使用本机 Google Chrome，覆盖桌面和手机视口；其他环境可调整 `playwright.config.js` 的 channel 并安装相应 Playwright 浏览器。

策略联调使用[本地模拟页](http://127.0.0.1:4173/examples/strategy.html?local=1)。把 Web 构建 `thinkingdata.umd.min.js`、`tdremoteconfig.umd.min.js` 和支持应用内消息的 `tdstrategy.umd.min.js` 放在 `examples/` 目录。联调页加载 `dist/td-content-ui.umd.min.js`，运行 `npm run dev` 时会自动生成。

点击「上报 login」后，采集和配置请求发往本地示例服务。任务命中后，策略 SDK 调用 `window.TDContentUI.contentUI` 弹窗。页面可查看下发 JSON 和策略回执，完整日志在浏览器控制台。

链路记录会显示策略回执和弹窗处理错误。Web 应用内消息的状态 `6` 表示任务触发成功，由策略 SDK 在处理弹窗前上报。Content UI 确认展示后，策略 SDK 上报状态 `14`，联调页显示「弹窗展示成功（14）」。

## 接入示例

默认使用共享实例 `contentUI.show(config, callbacks)`。第一次调用 `show` 时创建渲染器。各次展示使用自己的回调，关闭时调用返回的 `handle.close()`。需要自定义标签、尺寸或 CSP nonce 时，用 `createContentUI(options)` 创建独立实例。

```ts
import { contentUI } from 'td-content-ui-js';

const handle = contentUI.show(
  {
    template: { id: 'modal_image_text', version: 1 },
    data: {
      title: '欢迎回来',
      body: '发现更多精彩内容',
      image: { url: 'https://example.com/banner.png', alt: '活动图片' },
      buttons: [
        {
          id: 'primary',
          text: '立即查看',
          action: { type: 'WEB_URL', target: 'https://example.com/activity', dismiss: true },
        },
      ],
    },
    styles: { container: { cornerRadius: 16 } },
  },
  {
    actionHandlers: {},
    onShown(handle) {
      console.log('shown', handle.id);
    },
    onAction(event) {
      console.log('clicked', event.elementId);
    },
    onClose(event) {
      console.log('closed', event.reason);
    },
    onError(error) {
      console.error(error);
    },
  },
);

const result = await handle.ready;
// result.status: shown | closed | failed；始终 resolve，失败结果包含 error。
// 需要主动关闭时调用：handle.close();
// 独立实例由创建它的调用方负责 destroy()。
```

在 document.body 可用后调用 show。模块导入及实例创建不访问 DOM，可在 SSR 工程导入；实际渲染需要浏览器。

## 配置协议

```ts
{ template: { id, version: 1 }, data, styles?, behavior? }
```

| 模板 ID                 | 内容                                             |
| ----------------------- | ------------------------------------------------ |
| modal_image             | 居中图片，可带按钮                               |
| modal_image_text        | 居中图文，图片/标题/正文可选，整体内容不可为空   |
| bottom_sheet_image      | 手机贴底图片，PC 左下/右下图片                   |
| bottom_sheet_image_text | 手机贴底图文，PC 左下/右下图文                   |
| html                    | 隔离 HTML 文档，支持内联样式、内联脚本和动作标记 |

图片模板必须提供图片配置。结构化模板的图片地址和 `WEB_URL` 跳转地址都必须是带主机的 `http://` 或 `https://` 绝对 URL。SDK 也能从复制来的 Markdown 图片或链接中提取图片地址。图片地址无效、加载失败或超时时，使用内置占位图，保留原有文字、按钮和配置的图片比例。自由比例使用 16:9 占位图。结构化文案按纯文本处理。最多两个业务按钮，ID 为 1–64 位标识符（英文字母开头，后续允许数字、下划线、连字符），同一消息内唯一。

styles 可局部覆盖，缺省值来自独立模板预设；错误值不会被默认值掩盖。通过 createDefaultStyles(templateId) 获取完整样式快照。字段沿用现有 multiverse 语义：

- container：背景、圆角、maxWidth、widthPercent、landscapeWidthPercent。
- image：aspectRatio（含 auto）及 fit=cover。
- title/body：颜色、字号和对齐。
- buttonGroup.direction：horizontal/vertical。
- buttons.<id>：文字/背景/边框颜色、边框宽度、圆角、字号、paddingVertical。
- closeButton：图标颜色、圆底颜色和圆底透明度。
- overlay：颜色和透明度。
- bottomSheet.desktopPosition：left/right。

颜色使用六位十六进制值，透明度范围 0–1。PC 的 maxWidth 表示目标 CSS 像素宽度，并受可用区域 70% 上限约束。手机按横竖屏百分比展示。auto 设备模式将宽度不超过 600px 的视口按移动端处理，浏览器标识为手机时，超过 600px 的横屏视口也使用移动端宽度。接入方可显式指定 device。超高内容由外层滚动承载，关闭入口保持可达。

behavior 默认：

```json
{ "showCloseButton": true, "closeOnOverlayClick": false, "autoCloseSeconds": 0 }
```

autoCloseSeconds 为 0–60 的整数，0 禁用。实际展示后开始计时，页面隐藏期间暂停。Web 默认支持 Escape 关闭，等待页面可见后才通知 onShown。

移动或纯触屏环境下，如果关闭按钮和自动关闭都禁用，同时没有可点的遮罩关闭区域或可用的直接关闭动作，SDK 会显示关闭按钮作为兜底。

## 动作与回调

向 `show` 传入 `actionHandlers` 可启用 SDK 动作分发，传空对象即可启用默认网页跳转和 App 唤起。此时 `onAction` 通知点击，可用于埋点，动作执行由 SDK 和下表的处理器完成。

业务按钮的 `onAction` 包含 `elementId` 和 `buttonSlot`。标准按钮 `primary`、`secondary` 分别对应 1、2。模板包含自定义按钮 ID 时按配置顺序编号，HTML 使用源码中的按钮顺序。策略 SDK 据此上报按钮 1 的状态 `15` 和按钮 2 的状态 `16`。

HTML 脚本通过桥接接口或代码模拟点击时，仍可执行对应动作。启用 `actionHandlers` 时，脚本动作不会触发用于点击上报的 `onAction`。由宿主通过 `onAction` 执行动作时，可以用 `event.userInitiated` 区分 HTML 的真实点击和脚本动作。

| 动作           | SDK 动作分发                                                          |
| -------------- | --------------------------------------------------------------------- |
| NONE           | 仅图片可用，无操作                                                    |
| DISMISS        | 通知 `onAction` 并立即关闭                                            |
| WEB_URL        | 默认在新标签页打开已校验的 URL，可通过 `actionHandlers.navigate` 接管 |
| DEEP_LINK      | 点击时交给浏览器唤起对应 App，可通过 `actionHandlers.navigate` 接管   |
| SUPPRESS_TODAY | 由 `actionHandlers.suppressToday` 保存抑制，成功后关闭                |

导航处理器接收 `(action, handle)`，今日抑制处理器接收 `(handle)`。这两个处理器可以返回 Promise。跳转处理成功后按 `dismiss` 决定是否关闭（默认关闭），保存抑制成功后关闭。处理失败时通知 `onError` 并保留弹窗。等待期间忽略重复动作点击。缺少执行所需的处理器时报告 `ACTION_HANDLER_REQUIRED`。

默认网页跳转被浏览器拦截时会报告 `POPUP_BLOCKED`，弹窗保留，用户可重试。

`DEEP_LINK` 的 `target` 使用 App 已注册的自定义协议，例如 `myapp://activity/123`。SDK 将请求交给浏览器后按 `dismiss` 处理弹窗。实际打开取决于 App 是否已安装及浏览器是否允许唤起。

省略 `actionHandlers` 时，沿用由宿主在 `onAction` 中执行外部动作的接口。普通关闭不触发今日抑制，抑制的用户、任务和日期规则由接入方管理。

业务按钮、关闭按钮及可点击图片提供默认交互反馈：鼠标悬浮时轻微变化，按下时提供反馈。按钮动效不改变布局尺寸或配置的静态颜色；触屏不启用悬浮效果，系统开启“减少动态效果”时取消位移、缩放及过渡。异步业务动作等待期间，触发控件显示忙碌状态（aria-busy），其他业务控件暂时不可操作；关闭按钮及 Escape 仍可关闭弹窗。动作失败后恢复可交互状态。

## 生命周期

- `ui.show(config, callbacks?, options?)` 返回 id、只读 state、ready 和 close(reason?)。id 是页面内 UI 实例标识。
- state 可为 queued、preparing、visible、closed 或 failed。
- 无法恢复的配置错误同步抛出 UIError，同时通知 onError。HTML 初始化失败时异步通知 onError，ready 返回失败。图片替换为占位图时仍通过 onError 报告该图片问题，弹窗正常显示后 ready 返回 shown。
- HTML iframe 就绪后，SDK 会在宿主页可见时检查原文档的通信桥接。iframe 切换文档导致桥接失效时，SDK 会清理弹窗并报告 `HTML_DOCUMENT_CHANGED`。同一文档内的锚点变化可以继续使用。
- 宿主替换 `document.body` 时，SDK 会关闭脱离页面的弹窗，并在新页面内容中继续展示队列。
- 弹窗首次位于前台并完成绘制后会调用 `onShown`。如果用户先点到已可交互的弹窗，SDK 会在处理此次点击前同步调用 `onShown`。
- 关闭原因包括 programmatic、close_button、overlay、escape、auto_close、action、replaced、skipped 和 destroyed。
- 关闭与销毁幂等，清理 DOM、资源、监听器和计时器，恢复宿主滚动与焦点。无法展示时只通知 onError。
- destroy 仅关闭该实例持有的 UI；销毁后再次 show 抛出 DESTROYED。

实例选项：device=auto|desktop|mobile、zIndex（默认 2147483000）、resourceTimeoutMs（默认 10000，范围 100–60000）、nonce、labels.dialog/close。结构化模板使用 Shadow DOM，不依赖宿主 UI 框架。

## 弹窗展示策略

通过 `show` 的第三个参数为本次请求设置策略。当前页面内的共享实例和自建实例统一协调弹窗。

```ts
contentUI.show(config, callbacks, { strategy: 'single' });
```

| `strategy`       | 展示方式                                                                                                               |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `single`（默认） | 第一条请求开始准备和展示。在它结束前，后续 `single` 请求以 `skipped` 关闭。                                            |
| `queue`          | 按请求顺序排队，当前弹窗关闭或展示失败后继续。排队期间可通过 handle 取消。                                             |
| `stack`          | 新弹窗在就绪后叠到最上层。顶层接收鼠标和键盘交互，并计算自动关闭时间。关闭后恢复下层，`onShown` 每条弹窗最多触发一次。 |

混用策略时，`single` 会在已有弹窗准备或展示期间跳过，排队请求会在当前弹窗全部结束后继续。

## 接入现有 multiverse

adaptInAppMessage 接受对象或 JSON 字符串，将 image/image_text + layout 转为唯一模板 ID，保留已有样式和行为。不接收整份任务，不做受众、平台、日期或频控判断，不修改输入。

Web 策略 SDK 在任务通过校验后读取分组的 `content.inAppMessage` 并调用共享实例。使用此接入方式时，在首次展示前加载 `td-content-ui.umd.min.js`，让策略 SDK 能访问 `window.TDContentUI`。

策略 SDK 初始化时可传入 `popupStrategy: 'queue'` 等选项，调用 `show` 时会转发。服务端通过任务列表的先后顺序表达优先级，策略 SDK 按下发顺序处理任务。

如果单独使用 UI SDK，可以直接适配收到的模板配置：

```ts
import { contentUI, adaptInAppMessage } from 'td-content-ui-js';

contentUI.show(adaptInAppMessage(inAppMessage), {
  actionHandlers: {
    suppressToday: () => saveSuppression(),
  },
});
```

`saveSuppression` 由接入方实现。平台资格和已抑制消息的判断由接入方在展示前完成。

## HTML

```html
<article data-inapp-container>
  <h2>活动通知</h2>
  <button data-inapp-button="primary" data-inapp-action="DISMISS">关闭</button>
</article>
```

支持完整文档和片段，沿用 data-inapp-button/action/target/dismiss、data-inapp-close，内部轮播控件标记 data-inapp-control。可不传 data.buttons，由 SDK 从 HTML 标记提取；同时提供时，ID、文案和动作必须一致。运行时改写 DOM 属性不能替换已验证的业务动作。

SDK 在文档副本中应用容器、按钮、遮罩和关闭样式，正文和内联脚本由源码定义，不回写源码。沙箱内的 AEInAppBridge.close() 和 .action(buttonId) 仅提供受限动作能力。

业务按钮在 HTML 初始化后归入按钮组。同步内联脚本和 `DOMContentLoaded` 初始化可访问原有的按钮位置。

HTML 上限 200000 字符。iframe 开放脚本，不开放同源、顶层导航、弹窗、表单及下载权限；拒绝嵌套 frame/object/embed、base、meta refresh、外部脚本。CSP 限制连接和资源；允许 HTTP(S)/data/blob 图片，不能解释为完全无网络环境。不要向沙箱传入宿主凭证。

HTML 模板的 `<img>` 图片加载出错或初始加载超时时，就地替换成内置占位图。模板使用的正文、按钮及其他有效图片仍可展示。

宿主 CSP 仍然生效。nonce 用于 SDK 样式、沙箱内联脚本和样式；严格禁用 style attribute、srcdoc 或内联脚本的站点需单独联调。当前不提供 Trusted Types 策略。

## 构建及平台

`npm run build` 生成 ESM、CommonJS、UMD 和类型声明。`npm run release` 在 `dist/` 中额外生成三种压缩版和对应的 source map。

| 格式     | 压缩文件                   |
| -------- | -------------------------- |
| ESM      | `td-content-ui.esm.min.js` |
| CommonJS | `td-content-ui.min.cjs`    |
| UMD      | `td-content-ui.umd.min.js` |

`npm pack` 会运行 `release`，将压缩版一起打进 npm 包。UMD 可直接使用 `TDContentUI.contentUI.show()`，自定义实例使用 `TDContentUI.createContentUI(options)`。

依赖现代浏览器的 Shadow DOM、inert、AbortController、requestAnimationFrame、DOMParser 和 crypto.getRandomValues。浏览器回归使用 Chrome 桌面及手机视口；Safari、Firefox、iOS/Android WebView 真机仍需平台验收。

协作事项见 [multiverse 协议约定](docs/multiverse-contract.md)。

## 发布 npm 包

在发布服务器的项目根目录使用 Node.js 20 或更高版本，安装构建依赖并预览发布内容。

```bash
npm ci --include=dev
npm publish --dry-run
```

确认版本、文件清单和目标 registry 后执行 `npm publish`。发布时 `prepack` 会自动运行 `npm run release`，将 ESM、CommonJS、压缩版 UMD 和 TypeScript 声明打进 npm 包。
