# multiverse 协作约定（待共同确认）

Web 策略 SDK 通过 adaptInAppMessage 消费现有配置并调用共享展示实例。本文区分已实现的适配和待确认的协作事项。

## 首版无需前端修改

| 当前 multiverse           | UI SDK                  |
| ------------------------- | ----------------------- |
| image + modal             | modal_image             |
| image_text + modal        | modal_image_text        |
| image + bottom_sheet      | bottom_sheet_image      |
| image_text + bottom_sheet | bottom_sheet_image_text |
| html + modal              | html                    |

template.version 继续为 1，data/styles/behavior 由适配函数保留。JSON 字符串只解析一次。display.platforms 由调用方判断，不进入渲染协议；平台资格和手机布局独立。

SDK 不要求增加 contentType、delivery、任务或用户字段，原始任务结构可以保持。是否展示、如何关联统计，由接入方处理。

HTML 按钮组沿用 multiverse 的布局：按钮间距固定为 16px，顶部外边距为 20px。SDK 不额外注入按钮组内边距，容器和按钮组在 HTML 源码中已有的 padding 保留。

SDK 运行态增加统一的按钮悬浮、按下及异步处理反馈，不新增下发字段；结构化模板和 HTML 模板共用同一套交互样式。原有静态配色与布局尺寸保留，触屏及减少动态效果偏好单独适配。管理端如需在预览中呈现这些交互状态，可同步复用该规范。

## 建议共同确认

1. **唯一模板 ID**：后续是否由前端直接产出五个唯一 ID。目前无需迁移；现有编辑器只识别 image/image_text/html，未经协商不能切换保存格式。
2. **默认样式**：SDK 对齐当前五套预设。建议共用 JSON fixtures 分别验证前端序列化和 SDK 渲染，再根据后续需求讨论共享协议包。
3. **按钮槽位** SDK 通过 `onAction.buttonSlot` 返回按钮编号。仅使用标准 ID 的模板按 `primary`、`secondary` 固定映射 1、2。包含自定义 ID 时按配置顺序编号，HTML 使用源码顺序，与编辑器一致。
4. **HTML 双重配置**：允许只传 HTML；同时提供 data.buttons 时，ID、文案和动作必须与标记一致。前端保存前保持同步，不一致返回 HTML_BUTTON_MISMATCH。
5. **动作关闭**：启用 `actionHandlers` 后由 UI SDK 分发动作。Web 链接默认在新标签页打开，Deep Link 交给浏览器唤起 App，接入方可接管跳转。执行后按 dismiss 处理弹窗，SUPPRESS_TODAY 由接入方按业务范围保存后关闭。同步派发或自定义处理器报错时保留 UI。
6. **超高内容**：正常布局对齐预览，超出真实视口时由外层滚动，保证关闭可达。不增加 maxHeightPercent 或卡片内部高度截断，建议预览也采用此规则。
7. **尺寸语义**：保留 maxWidth 名称，表示 PC 目标 CSS 像素宽度，受可用区域 70% 限制。手机按横竖屏百分比展示。auto 模式使用 600px 视口宽度判断，并按浏览器标识识别更宽的手机横屏。宿主可显式指定设备类别。
8. **HTML 能力**：支持内联脚本实现轮播，不支持外部脚本。导航由 UI SDK 使用已校验的按钮动作分发，Deep Link 走 SDK 的默认 App 唤起逻辑。真实动作通过运行态验证。

## 联调验收

- 五套完整配置：双按钮、独立样式、横竖屏宽度。
- 图片自由/固定比例、长文案、超高内容、透明关闭圆底、零边框和内边距。
- HTML 文档/片段、轮播、按钮表单同步、共享样式和缺省关闭节点。
- 跳转 dismiss=true/false、今日抑制、动作失败与重复点击。
- 未知版本、损坏 JSON、Markdown 包装图片 URL、图片失败和 HTML 标记冲突。

到达/点击系统事件、状态码和 SQL 统计由策略、Analytics、服务端链路另行确认；UI SDK 只提供生命周期回调。
